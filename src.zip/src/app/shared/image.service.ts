import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http'
import { environment } from 'src/environments/environment';
import { Observable, Subject } from 'rxjs'

@Injectable({
  providedIn: 'root'
})
export class ImageService {
  private query: string;
  data: any;
  favArray: any = [];
  
  
	private API_KEY: string = environment.PIXABAY_API_KEY;
	private API_URL: string = environment.PIXABAY_API_URL;
	private URL: string = this.API_URL + this.API_KEY + '&q=';
	private perPage: string = "&per_page=10";
	getImage(query){
    return this.http.get(this.URL + query + this.perPage)
  }
  constructor(private http:HttpClient) { }

  getImages(searchQuery:string){
    console.log(searchQuery)
    return this.http.get("https://api.unsplash.com/search/photos?query="+searchQuery+"&client_id=i0IW-tfZm9qtQ4aiTni5-__pJS9Tu-IUTaIVYxTKZ0U");
  }
  private subject = new Subject<any>();
 
  sendMessage(value: object) {
    this.favArray.push(value)
    console.log(this.favArray)
      this.subject.next({ text: this.favArray });
  }
 
  clearMessages() {
      this.subject.next();
  }
 
  getMessage(): Observable<any> {
      return this.subject.asObservable();
  }
dataSetter(obj:any){
  this.favArray.push(obj)
    this.data=this.favArray;
  }
 
dataGetter():any{
    return this.data;
  }
 
}
