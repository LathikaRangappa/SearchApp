import { Component, OnInit } from '@angular/core';
import { ImageService } from '../shared/image.service'

@Component({
  selector: 'app-fav',
  templateUrl: './fav.component.html',
  styleUrls: ['./fav.component.css']
})
export class FavComponent implements OnInit {
  FavData: any;

  constructor(private serv:ImageService) { }

  ngOnInit(): void {
    this.FavoritiesFunc();
  }
  
  FavoritiesFunc(){
    this.serv.getMessage().subscribe((message)=>{
      console.log(message)
      this.FavData = message.text;
      console.log(this.FavData)
    });
    this.FavData=this.serv.dataGetter();
    console.log(this.FavData);
  }
}
